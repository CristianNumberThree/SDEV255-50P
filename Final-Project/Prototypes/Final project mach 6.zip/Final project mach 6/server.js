const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

// Middleware
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
}));
app.use(passport.initialize());
app.use(passport.session());

// Load database (db.json)
const dbPath = './db.json';
const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));

// Save database
function saveDb() {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
}

// Passport Configuration
passport.use(new LocalStrategy(async (username, password, done) => {
    const user = db.users.find(user => user.username === username);
    if (!user) return done(null, false, { message: 'Incorrect username.' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return done(null, false, { message: 'Incorrect password.' });

    return done(null, user);
}));

passport.serializeUser((user, done) => {
    done(null, user.username);
});

passport.deserializeUser((username, done) => {
    const user = db.users.find(user => user.username === username);
    done(null, user);
});

// Middleware to check authentication
function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated()) return next();
    res.redirect('/login');
}

// Middleware for role-based access
function ensureRole(role) {
    return (req, res, next) => {
        if (req.user && req.user.role === role) return next();
        res.status(403).send('Forbidden');
    };
}

// Routes
app.get('/', (req, res) => {
    res.render('index', { user: req.user });
});

// Login
app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/login',
    failureFlash: true,
}));

// Register
app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', async (req, res) => {
    const { username, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    db.users.push({ username, password: hashedPassword, role });
    saveDb();

    res.redirect('/login');
});

// Logout
app.get('/logout', (req, res) => {
    req.logout(() => res.redirect('/login'));
});

// Courses (Students can only manage their own courses)
app.get('/courses', ensureAuthenticated, (req, res) => {
    const courses = req.user.role === 'staff' ? db.courses : db.courses.filter(c => c.createdBy === req.user.username);
    res.render('courses', { courses, user: req.user });
});

app.post('/courses', ensureAuthenticated, (req, res) => {
    const { course, teacher } = req.body;

    db.courses.push({ course, teacher, createdBy: req.user.username });
    saveDb();

    res.redirect('/courses');
});

app.post('/courses/delete', ensureAuthenticated, (req, res) => {
    const { courseId } = req.body;
    const courseIndex = db.courses.findIndex(c => c.id === courseId);

    if (courseIndex > -1) {
        const course = db.courses[courseIndex];
        if (req.user.role === 'staff' || course.createdBy === req.user.username) {
            db.courses.splice(courseIndex, 1);
            saveDb();
        }
    }

    res.redirect('/courses');
});

// Listen
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
